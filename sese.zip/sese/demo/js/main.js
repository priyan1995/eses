(function ($) {

  $(window).scroll(function () {
    if ($(this).scrollTop() > 100) {
      $('.scrollup').fadeIn();
    } else {
      $('.scrollup').fadeOut();
    }
  });
  $('.scrollup').click(function () {
    $("html, body").animate({
      scrollTop: 0
    }, 1000);
    return false;
  });

  // local scroll
  jQuery('.navbar').localScroll({
    hash: true,
    offset: {
      top: 0
    },
    duration: 800,
    easing: 'easeInOutExpo'
  });

  $(".navbar-collapse a").on('click', function() {
    $(".navbar-collapse.collapse").removeClass('in');
  });

  // portfolio
  if ($('.isotopeWrapper').length) {

    var $container = $('.isotopeWrapper');
    var $resize = $('.isotopeWrapper').attr('id');
    // initialize isotope

    $container.isotope({
      itemSelector: '.isotopeItem',
      resizable: false, // disable normal resizing
      masonry: {
        columnWidth: $container.width() / $resize
      }
    });

    $('#filter a').click(function () {
      $('#filter a').removeClass('current');
      $(this).addClass('current');
      var selector = $(this).attr('data-filter');
      $container.isotope({
        filter: selector,
        animationOptions: {
          duration: 1000,
          easing: 'easeOutQuart',
          queue: false
        }
      });
      return false;
    });

    $(window).smartresize(function () {
      $container.isotope({
        // update columnWidth to a percentage of container width
        masonry: {
          columnWidth: $container.width() / $resize
        }
      });
    });

  }

  // fancybox
  jQuery(".fancybox").fancybox();

  if (Modernizr.mq("screen and (max-width:1024px)")) {
    jQuery("body").toggleClass("body");

  } else {
    var s = skrollr.init({
      mobileDeceleration: 1,
      edgeStrategy: 'set',
      forceHeight: true,
      smoothScrolling: true,
      smoothScrollingDuration: 300,
      easing: {
        WTF: Math.random,
        inverted: function (p) {
          return 1 - p;
        }
      }
    });
  }

  //scroll menu
  jQuery('.appear').appear();
  jQuery(".appear").on("appear", function (data) {
    var id = $(this).attr("id");
    jQuery('.nav li').removeClass('active');
    jQuery(".nav a[href='#" + id + "']").parent().addClass("active");
  });


  //parallax
  var isMobile = false;

  if (Modernizr.mq('only all and (max-width: 1024px)')) {
    isMobile = true;
  }

  if (isMobile == false && ($('#parallax1').length || isMobile == false && $('#parallax2').length || isMobile == false && $('#testimonials').length)) {

    $(window).stellar({
      responsive: true,
      scrollProperty: 'scroll',
      parallaxElements: false,
      horizontalScrolling: false,
      horizontalOffset: 0,
      verticalOffset: 0
    });

  }
  
// service block view more btn function
var serviceblock = $("#services .service-block");

serviceblock.find(".service-more-img").click(function(ele) {
  
  let viewMoreimage = $(this)
  let secondPara = viewMoreimage.parent().find(".second")

  secondPara.toggle("slow")
  
});
  
// what we offer view more btn function
var offerBlock = $("#line-pricing");

offerBlock.find(".offer-viewmore").click(function(ele) {
  
  let viewMoreimage = $(this)
  let secondPara = viewMoreimage.parent().find(".view-content")
  secondPara.toggle("slow")
  
});
  
var counterIsStarted = false;
  
function counter(start, end, element, finish=null){
  
  var numberEle = element.find(".count-number")
  
  // start counter
  var intervelObj = setInterval(function(){ 
    
    // if start and end is not equeal increment
    if(start <= end){
      numberEle.html(start)  
      start++;
    }else{
            
      // has text
      if(finish){
        numberEle.html(`All`)
      }
      
      clearInterval(intervelObj);
    }
    
  }, 40);
  
}
  
// counter
$(window).on("scroll load", function(event){
  
  // scroll top values
  var getWindowScrollTop = $(window).scrollTop();
  var counterSection = $("#counter")
  var counterScrollTop = counterSection.offset().top;
  
  // counter start and end values when window
  var counterStart = counterScrollTop - 400
  var counterEnd = counterScrollTop + 400
  
  // counter objects
  var countYearExpObj = $("#counter #count-year");
  var countClientObj = $("#counter #client-base");
  var countCompanyObj = $("#counter #company");
  var countIndrustryObj = $("#counter #indrustry");
 
  // counter started
  if(counterStart <= getWindowScrollTop){

      // if not started run it
      // when it started dont run
      if(counterIsStarted){
        
        console.log("dont run")
      }else{
        
        counter(0, 25, countYearExpObj) // counter exp 
        counter(0, 150, countClientObj) // counter exp 
        counter(0, 250, countCompanyObj) // counter exp 
        counter(0, 12, countIndrustryObj, "All") // counter exp 
        
      }
    
        

    
      counterIsStarted = true;
      return null;
  }
  
  console.log("window", getWindowScrollTop);
  console.log("counter", counterScrollTop);
 
})
  

})(jQuery);
